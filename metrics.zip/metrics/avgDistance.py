import cv2

## load matchings
## note: load using a utility

## for each slide:
## ## for each video frame:
## ## ## dict(x, y) = apply(distance metric)

## plot (x, y) using utility
## plot ( (x, y), savePath )